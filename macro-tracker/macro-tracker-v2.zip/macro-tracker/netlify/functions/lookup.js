exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const { query } = JSON.parse(event.body || '{}');
  if (!query) return { statusCode: 400, body: 'Missing query' };

  const prompt = `You are a precise nutrition database. The user wants to log: "${query}"

Return ONLY a raw JSON object, no markdown, no explanation, just JSON:
{"name":"descriptive food name with portion","note":"brief source or assumption","calories":0,"protein_g":0,"carbs_g":0,"fat_g":0,"sugar_g":0}

Use USDA or standard food label values. Round all numbers to nearest integer. If portion unspecified, assume standard single serving and note it.`;

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 500,
      messages: [{ role: 'user', content: prompt }]
    })
  });

  if (!res.ok) {
    const err = await res.text();
    return { statusCode: 500, body: JSON.stringify({ error: err }) };
  }

  const data = await res.json();
  const raw = (data.content || []).map(b => b.text || '').join('').trim();
  const s = raw.indexOf('{'), e = raw.lastIndexOf('}');
  if (s === -1) return { statusCode: 500, body: JSON.stringify({ error: 'No JSON in response' }) };

  const parsed = JSON.parse(raw.slice(s, e + 1));

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(parsed)
  };
};
